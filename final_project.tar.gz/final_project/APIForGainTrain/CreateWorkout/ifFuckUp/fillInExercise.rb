#!/usr/bin/ruby
require 'fastimage'
require 'net/http'
require 'json'

uri = URI('http://localhost:3000/api/v1/exercises')
req = Net::HTTP::Post.new(uri, 'Content-Type' => 'application/json')
req = Net::HTTP::Post.new(uri, 'Content-Type' => 'application/json')
    req.body = {"exercise" => {"name" => "Hammer Curl", "reps" => "10-12", "sets" => "4", "masterset_id" => 63 }}.to_json
    res = Net::HTTP.start(uri.hostname, uri.port) do |http|
      http.request(req)
    end
