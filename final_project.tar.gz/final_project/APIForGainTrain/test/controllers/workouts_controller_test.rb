require 'test_helper'

class WorkoutsControllerTest < ActionController::TestCase
  setup do
    @workout = workouts(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:workouts)
  end

  test "should create workout" do
    assert_difference('Workout.count') do
      post :create, workout: { body_type: @workout.body_type, creator: @workout.creator, img_height: @workout.img_height, img_url: @workout.img_url, img_width: @workout.img_width, name: @workout.name }
    end

    assert_response 201
  end

  test "should show workout" do
    get :show, id: @workout
    assert_response :success
  end

  test "should update workout" do
    put :update, id: @workout, workout: { body_type: @workout.body_type, creator: @workout.creator, img_height: @workout.img_height, img_url: @workout.img_url, img_width: @workout.img_width, name: @workout.name }
    assert_response 204
  end

  test "should destroy workout" do
    assert_difference('Workout.count', -1) do
      delete :destroy, id: @workout
    end

    assert_response 204
  end
end
