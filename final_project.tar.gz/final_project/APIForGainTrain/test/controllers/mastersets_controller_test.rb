require 'test_helper'

class MastersetsControllerTest < ActionController::TestCase
  setup do
    @masterset = mastersets(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:mastersets)
  end

  test "should create masterset" do
    assert_difference('Masterset.count') do
      post :create, masterset: { workout_id: @masterset.workout_id }
    end

    assert_response 201
  end

  test "should show masterset" do
    get :show, id: @masterset
    assert_response :success
  end

  test "should update masterset" do
    put :update, id: @masterset, masterset: { workout_id: @masterset.workout_id }
    assert_response 204
  end

  test "should destroy masterset" do
    assert_difference('Masterset.count', -1) do
      delete :destroy, id: @masterset
    end

    assert_response 204
  end
end
