require 'test_helper'

class MastersetTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
