Rails.application.routes.draw do
 namespace:api, defaults: {format: :json} do 
   namespace :v1 do
  get '/workouts/findIDs', :to => 'workouts#new_workouts'
  resources :exercises
  resources :mastersets
  resources :workouts
   end
 end
  
end
