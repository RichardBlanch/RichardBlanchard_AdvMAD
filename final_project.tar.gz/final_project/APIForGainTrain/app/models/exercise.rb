class Exercise < ActiveRecord::Base
  belongs_to :masterset
end
