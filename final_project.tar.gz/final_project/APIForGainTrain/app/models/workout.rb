class Workout < ActiveRecord::Base
  has_many :mastersets
end
