class  Api::V1::MastersetsController < ApplicationController
  

  # GET /mastersets
  # GET /mastersets.json
  def index
    @mastersets = Masterset.all

    render json: @mastersets
  end

  # GET /mastersets/1
  # GET /mastersets/1.json
  def show
    @masterset = Masterset.find(params[:id])
    render json: @masterset
  end

  # POST /mastersets
  # POST /mastersets.json
  def create
     @masterset = Masterset.new(masterset_params)
    if @masterset.save
      render json: @masterset, status: :created
    else
      render json: @masterset.errors, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /mastersets/1
  # PATCH/PUT /mastersets/1.json
  def update
    @masterset = Masterset.find(params[:id])

    if @masterset.update(masterset_params)
      head :no_content
    else
      render json: @masterset.errors, status: :unprocessable_entity
    end
  end

  # DELETE /mastersets/1
  # DELETE /mastersets/1.json
  def destroy
    @masterset.destroy

    head :no_content
  end
 private
    # Use callbacks to share common setup or constraints between actions.
    def set_master_set
      @master_set = MasterSet.find(params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def masterset_params
      params.require(:masterset).permit(:workout_id)
    end
end
