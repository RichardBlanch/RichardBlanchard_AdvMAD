class  Api::V1::WorkoutsController < ApplicationController
  
  
  
  
  def new_workouts
    @workouts = Workout.where(params["where"])
    @workouts = @workouts.order(created_at: :desc)
    render :json => @workouts, serializer:WorkoutSerializer
  end

  # GET /workouts
  # GET /workouts.json
  def index
    @workouts = Workout.all
    render :json => @workouts, serializer:WorkoutSerializer
  end

  # GET /workouts/1
  # GET /workouts/1.json
  def show
    @workout = Workout.find(params[:id])
    render json: @workout
  end

  # POST /workouts
  # POST /workouts.json
  def create
    @workout = Workout.new(workout_params)

    if @workout.save
      render json: @workout, status: :created
    else
      render json: @workout.errors, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /workouts/1
  # PATCH/PUT /workouts/1.json
  def update
    @workout = Workout.find(params[:id])

    if @workout.update(workout_params)
      head :no_content
    else
      render json: @workout.errors, status: :unprocessable_entity
    end
  end

  # DELETE /workouts/1
  # DELETE /workouts/1.json
  def destroy
    @workout.destroy

    head :no_content
  end

  private

    def set_workout
      @workout = Workout.find(params[:id])
    end

    def workout_params
      params.require(:workout).permit(:creator, :name, :body_type, :img_width, :img_height, :img_url)
    end
end
