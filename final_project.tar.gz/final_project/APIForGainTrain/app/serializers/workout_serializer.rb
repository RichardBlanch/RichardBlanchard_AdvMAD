class WorkoutSerializer < ActiveModel::Serializer
  attributes  :workout_plan

  def workout_plan
    object.as_json(:include => {:mastersets => {except: [:created_at,:id,:workout_id,:updated_at],:include => :exercises }})
    #object.as_json(:include => {:weeks => {except: [:created_at,:id,:workout_id,:updated_at],:include => {:days => {except: [:created_at,:id,:week_id,:updated_at],:include => {:master_sets => {except: [:created_at,:id,:Day,:updated_at,:day_id],:include => :exercises}}}}}})
    #object.as_json(:include => {:weeks => {except: [:created_at,:id,:workout_id,:updated_at],:include => {:days => {except: [:created_at,:id,:week_id,:updated_at],:include => {:master_sets => {except: [:created_at,:id,:Day,:updated_at,:day_id], include: => {:}}}}}}})
  end
end

