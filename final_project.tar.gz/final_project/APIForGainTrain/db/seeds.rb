# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).


Workout.create(:name => "Dustin Myers", :name => "Hill Sprint Intervals",
 :body_type => "Cardio", :img_width => 354, :img_height => 221, 
:img_url => "https://www.muscleandstrength.com/sites/default/files/field/feature-image/workout/hiit_treadmill_workouts_for_fat_loss.jpg")
Masterset.create(:workout_id => 1)
Exercise.create(:reps => "4", :sets => "15% Incline - 7 MPH - 30 sec on. / 30 sec. off", :masterset_id => 1)

Masterset.create(:workout_id => 1)
Exercise.create(:reps => "4", :sets => "12% Incline - 8 MPH - 30 sec on. / 30 sec. off", :masterset_id => 2)

Masterset.create(:workout_id => 1)
Exercise.create(:reps => "4", :sets => "9% Incline - 9 MPH - 30 sec on. / 30 sec. off", :masterset_id => 3)

Masterset.create(:workout_id => 1)
Exercise.create(:reps => "4", :sets => "6% Incline - 10 MPH - 30 sec on. / 30 sec. off", :masterset_id => 4)
=begin
Workout.create(:creator => "Dustin Myers", :name => "The 'Get Peeled'", 
:body_type => "Cardio", :img_width => 354, :img_height => 221, 
:img_url => "https://www.muscleandstrength.com/sites/default/files/field/feature-image/workout/hiit_treadmill_workouts_for_fat_loss.jpg")

Masterset.create(:workout_id => 2)
Exercise.create(:name => "Pull-Ups", :reps => "15", :sets => "6 ", :masterset_id => 5)
Exercise.create(:name => "Push-Ups", :reps => "20", :sets => "6 ", :masterset_id => 5)
Exercise.create(:name => "Chin-Ups", :reps => "10", :sets => "6 ", :masterset_id => 5)
Exercise.create(:name => "Narrow Push-Ups", :reps => "15", :sets => "6 ", :masterset_id => 5)
Exercise.create(:name => "1/4 mile run", :reps => "15", :sets => "6 ", :masterset_id => 5)

Workout.create(:creator => "Dustin Myers", :name => "The 2-Mile Turn-Up", 
:body_type => "Cardio", :img_width => 354, :img_height => 221, 
:img_url => "https://www.muscleandstrength.com/sites/default/files/field/feature-image/workout/hiit_treadmill_workouts_for_fat_loss.jpg")

Masterset.create(:workout_id => 3)
Exercise.create(:name => "Treadmill Run 7 MPH", :reps => "1/4 mile", :sets => "2", :masterset_id => 6)
Exercise.create(:name => "Treadmill Run 8 MPH", :reps => "1/4 mile", :sets => "2", :masterset_id => 6)
Exercise.create(:name => "Treadmill Run 9 MPH", :reps => "1/4 mile", :sets => "2", :masterset_id => 6)
Exercise.create(:name => "Treadmill Run 10 MPH", :reps => "1/4 mile", :sets => "2", :masterset_id => 6)

Workout.create(:creator => "Dustin Myers", 
:name => "20 Minute Beatdown", 
:body_type => "HIIT", 
:img_width => 354, 
:img_height => 221, 
:img_url => "https://www.muscleandstrength.com/sites/default/files/field/feature-image/workout/hiit_treadmill_workouts_for_fat_loss.jpg")

Masterset.create(:workout_id => 4)
Exercise.create(:name => "Chin-Ups", :reps => "1 minute", :sets => "5 ", :masterset_id => 10)
Exercise.create(:name => "Treadmill Run", :reps => "1 minute", :sets => "5 ", :masterset_id => 10)
Exercise.create(:name => "Push-Ups", :reps => "1 minute", :sets => "5 ", :masterset_id => 10)
Exercise.create(:name => "Treadmill Run", :reps => "1 minute", :sets => "5 ", :masterset_id => 10)


Workout.create(:creator => "Pete Khatcherian", 
:name => "“No Juice” Advanced Bodybuilding Workout Routine - Day 1: Chest & Back", 
:body_type => "Chest, Back", 
:img_width => 800, 
:img_height => 500, 
:img_url => "https://www.muscleandstrength.com/sites/default/files/images/articles/no_juice_1a.jpg")



Masterset.create(:workout_id => 5)
Exercise.create(:name => "Incline Dumbbell Press", :reps => "6-8", :sets => "3", :masterset_id => 12)

Masterset.create(:workout_id => 5)
Exercise.create(:name => "Dips", :reps => "6-10", :sets => "3", :masterset_id => 13)

Masterset.create(:workout_id => 5)
Exercise.create(:name => "Pullups", :reps => "5-8", :sets => "3", :masterset_id => 14)

Masterset.create(:workout_id => 5)
Exercise.create(:name => "Pendlay Rows", :reps => "6-10", :sets => "3", :masterset_id => 15)

Masterset.create(:workout_id => 5)
Exercise.create(:name => "Pulldowns", :reps => "6-10", :sets => "3", :masterset_id => 16)

Workout.create(:creator => "Pete Khatcherian", 
:name => "“No Juice” Advanced Bodybuilding Workout Routine - Day 2: Legs", 
:body_type => "Legs", 
:img_width => 800, 
:img_height => 500, 
:img_url => "https://www.muscleandstrength.com/sites/default/files/images/articles/no_juice_1a.jpg")

Masterset.create(:workout_id => 6)
Exercise.create(:name => "Squats (50% Max of 5 rep max)", :reps => "5", :sets => "1", :masterset_id => 17)
Exercise.create(:name => "Squats (60% Max of 5 rep max)", :reps => "5", :sets => "1", :masterset_id => 17)
Exercise.create(:name => "Squats (70% Max of 5 rep max)", :reps => "5", :sets => "1", :masterset_id => 17)
Exercise.create(:name => "Squats (80% Max of 5 rep max)", :reps => "5", :sets => "1", :masterset_id => 17)
Exercise.create(:name => "Squats (90% Max of 5 rep max)", :reps => "5", :sets => "1", :masterset_id => 17)
Exercise.create(:name => "Squats (100% Max of 5 rep max)", :reps => "5", :sets => "1", :masterset_id => 17)


Masterset.create(:workout_id => 6)
Exercise.create(:name => "Leg Press", :reps => "6-10", :sets => "3", :masterset_id => 20)

Masterset.create(:workout_id => 6)
Exercise.create(:name => "Stiff-Legged Deadlift", :sets => "5", :reps => "5", :masterset_id => 21)

Masterset.create(:workout_id => 6)
Exercise.create(:name => "Hamstring Curls", :sets => "3", :reps => "6-8", :masterset_id => 22)

Masterset.create(:workout_id => 6)
Exercise.create(:name => "Calf-Raise", :sets => "5", :reps => "10", :masterset_id => 23)
 

Workout.create(:creator => "Pete Khatcherian", 
:name => "“No Juice” Advanced Bodybuilding Workout Routine - Day 3: Shoulders & Arms", 
:body_type => "Shoulders, Arms", 
:img_width => 800, 
:img_height => 500, 
:img_url => "https://www.muscleandstrength.com/sites/default/files/images/articles/no_juice_1a.jpg")

Masterset.create(:workout_id => 7)
Exercise.create(:name => "Military Press or Dumbbell Press", :sets => "3", :reps => "6-8", :masterset_id => 24)

Masterset.create(:workout_id => 7)
Exercise.create(:name => "Lateral Raises", :sets => "5", :reps => "10", :masterset_id => 25)

Masterset.create(:workout_id => 7)
Exercise.create(:name => "Barbell Curls", :sets => "5", :reps => "6-10", :masterset_id => 26)

Masterset.create(:workout_id => 7)
Exercise.create(:name => "Dumbbell Curls", :sets => "3", :reps => "6-10", :masterset_id => 27)


Workout.create(:creator => "Pete Khatcherian", 
:name => "“No Juice” Advanced Bodybuilding Workout Routine - Day 5: Chest, Shoulders & Triceps", 
:body_type => "Chest, Arms", 
:img_width => 800, 
:img_height => 500, 
:img_url => "https://www.muscleandstrength.com/sites/default/files/images/articles/no_juice_1a.jpg")

Masterset.create(:workout_id => 8)
Exercise.create(:name => "Flat Dumbbell Press", :sets => "5", :reps => "20-6 (Pyramiding)", :masterset_id => 28)

Masterset.create(:workout_id => 8)
Exercise.create(:name => "Incline Dumbbell Press", :sets => "3", :reps => "6-10", :masterset_id => 29)

Masterset.create(:workout_id => 8)
Exercise.create(:name => "Hammer Strength Press", :sets => "3", :reps => "10", :masterset_id => 30)

Masterset.create(:workout_id => 8)
Exercise.create(:name => "Cable Flys", :sets => "3", :reps => "10", :masterset_id => 31)

Masterset.create(:workout_id => 8)
Exercise.create(:name => "Lateral Raises", :sets => "5", :reps => "15-20", :masterset_id => 32)

Masterset.create(:workout_id => 8)
Exercise.create(:name => "Reverse-Grip Pull-Downs", :sets => "5", :reps => "15-20", :masterset_id => 33)
Left Off - https://www.muscleandstrength.com/workouts/no-juice-bodybuilding-workout-routine (Day 6)


Workout.create(:creator => "MusclePharm", 
:name => "Arm Craziness", 
:body_type => "Arms", 
:img_width => 354, 
:img_height => 708, 
:img_url => "https://s-media-cache-ak0.pinimg.com/736x/9d/86/b1/9d86b149eeeb38fd482abc0f6d31b1ba.jpg")


Masterset.create(:workout_id => 11)
Exercise.create(:name => "Straight Barbell Curls", :sets => "6", :reps => "20, 20, 15, 12, 10, 8", :masterset_id => 41)
Exercise.create(:name => "EZ Bar Skull Crushers", :sets => "6", :reps => "20, 20, 15, 12, 10, 8", :masterset_id => 41)

Masterset.create(:workout_id => 11)
Exercise.create(:name => "Straight Bar Push-Downs", :sets => "5", :reps => "20 Full, 20 1/4 Reps", :masterset_id => 42)
Exercise.create(:name => "Band Push-Downs", :sets => "5", :reps => "20", :masterset_id => 42)
Exercise.create(:name => "Alternating Dumbbell Curls", :sets => "5", :reps => "12", :masterset_id => 42)
Exercise.create(:name => "Alternating Dumbbell Hammer Curls", :sets => "5", :reps => "12", :masterset_id => 42)

Masterset.create(:workout_id => 11)
Exercise.create(:name => "Reverse Curls", :sets => "4", :reps => "28 Method", :masterset_id => 43)
Exercise.create(:name => "Bodyweight Skulls", :sets => "4", :reps => "10", :masterset_id => 43)

Masterset.create(:workout_id => 11)
Exercise.create(:name => "Concentration Curls", :sets => "3", :reps => "12", :masterset_id => 44)
Exercise.create(:name => "Wrist Curls", :sets => "3", :reps => "20", :masterset_id => 44)

Masterset.create(:workout_id => 11)
Exercise.create(:name => "Back Extensions - 45 Degree Angle", :sets => "2-3", :reps => "50", :masterset_id => 45)
Exercise.create(:name => "Back Extensions - 90 Degree Angle", :sets => "2-3", :reps => "25", :masterset_id => 45)
Exercise.create(:name => "Toes to Bar", :sets => "2-3", :reps => "15", :masterset_id => 45)
=end









