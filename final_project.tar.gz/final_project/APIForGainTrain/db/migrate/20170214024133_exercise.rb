class Exercise < ActiveRecord::Migration
  def change
  end
end
