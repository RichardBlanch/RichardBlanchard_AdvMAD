class CreateWorkouts < ActiveRecord::Migration
  def change
    create_table :workouts do |t|
      t.string :creator
      t.string :name
      t.string :body_type
      t.integer :img_width
      t.integer :img_height
      t.string :img_url

      t.timestamps null: false
    end
  end
end
