//
//  MasterSet+CoreDataClass.swift
//  GainnTrainn
//
//  Created by Rich Blanchard on 2/16/17.
//  Copyright © 2017 Rich. All rights reserved.
//

import Foundation
import CoreData


public class MasterSet: NSManagedObject {

}
