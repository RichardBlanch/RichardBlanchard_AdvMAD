//
//  WorkoutRow.swift
//  GainnTrainn
//
//  Created by Rich Blanchard on 2/20/17.
//  Copyright © 2017 Rich. All rights reserved.
//

import Foundation
import WatchKit
class WorkoutRow: NSObject {
    
    @IBOutlet var workoutImageView: WKInterfaceImage!
    @IBOutlet var nameLabel: WKInterfaceLabel!
    

}
